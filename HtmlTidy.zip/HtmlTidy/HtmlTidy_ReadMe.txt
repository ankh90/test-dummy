HTML Tidy support for Beyond Compare 2
Version 1.0.2, released 10-September-2007
by Scooter Software


Abstract
--------

These rules are an add-on to Beyond Compare that uses HTML Tidy to format
HTML and XML files before comparing them.  This example uses a freeware
converter, but other programs should work with minimal changes.


Installation
------------

1) Extract all files in HtmlTidy.zip into your Beyond Compare installation
   directory.  By default, this would be:
     C:\Program Files\Beyond Compare 2

   The extraction should create 4 files in the new directory:
     C:\Program Files\Beyond Compare 2\HtmlTidy\

2) Run Beyond Compare and from the "Tools" menu select "Import Settings...".

3) In "Select import file", enter the name of the rules file:
     C:\Program Files\Beyond Compare 2\HtmlTidy\HtmlTidy.xml

   Click "Next".  In the "Pick rules to import" list, "HTML Tidy", 
   "XML Tidy", and "XML Sorted Tidy" should be checked.  Click "Next" again, then click "Finish" to
   import the rules.

4) Whenever you load a pair of HTML or XML files in the file viewer Beyond
   Compare will now format the files before displaying the comparison.  You can manually select XML Sorted
   Tidy to sort the elements in an XML node.


Requirements
------------

Beyond Compare 2.1 or higher
Html Tidy (included)
  http://tidy.sourceforge.net/


History
-------
 9/10/07 v1.0.2
		  Added XML Tidy Sort.
		  Updated Tidy.exe

 4/5/04  v1.0.1
          Added XML Tidy.

 1/16/04  v1.0
          Official release.


To Contact Us
-------------

If you have any questions, comments or suggestions, contact
support at:

	Scooter Software
	2828 Marshall Court, #112
	Madison, WI  53705-2276

	web site:  http://www.scootersoftware.com/
	email:     support@scootersoftware.com
